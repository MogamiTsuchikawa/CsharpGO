{
	static class main
	{
		[STAThread]
		static void Main()
		{
			
		}
	}
}
